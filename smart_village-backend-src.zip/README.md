1. Buat Database dengan nama "smartvillage"
2. Klik 2x atau jalankan smart_village-bakend.exe
3. Done.